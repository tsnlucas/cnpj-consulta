
# Consulta de CNPJs em Massa

Este projeto permite consultar CNPJs em massa a partir de uma planilha Excel e exibir os resultados em uma interface gráfica.

## Estrutura do Projeto
- **src/**: Contém os arquivos principais do projeto.
  - `main.py`: Ponto de entrada do aplicativo.
  - `consulta_cnpj_interface.py`: Interface gráfica principal.
  - `cnpj_consulta_thread.py`: Lógica de consulta de CNPJs em segundo plano.
  - `instrucoes_tab.py`: Aba de instruções para o usuário.
- **assets/**: Contém recursos como imagens.
  - `querydocs.png`: Exemplo de estrutura de arquivo Excel.

## Instruções de Instalação
1. Clone este repositório.
2. Instale as dependências com `pip`:
   ```bash
   pip install PyQt5 openpyxl requests
   ```

## Como Executar
1. Execute o arquivo `main.py` para abrir a interface gráfica:
   ```bash
   python src/main.py
   ```

2. Na interface, abra uma planilha Excel com uma lista de CNPJs e inicie a consulta.

## Licença
Veja o arquivo LICENSE.txt para detalhes.
